def boo():
  return "Boo"